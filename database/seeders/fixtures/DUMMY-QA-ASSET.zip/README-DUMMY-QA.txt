PAKET DUMMY QA INDOFX

File ini hanya untuk menguji alur klaim dan unduhan.
Ini bukan paket Unity atau aset asli.
Penjual harus menggantinya dengan paket asli sebelum penjualan nyata.
